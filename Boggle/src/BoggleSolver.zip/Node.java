public class Node 
{
	private static final int R = 26; 
	public Node[] next = new Node[R];
    public boolean isString;
}
