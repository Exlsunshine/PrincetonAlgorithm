import java.util.TreeSet;



public class BoggleSolver 
{
	private Trie26 trieSet;
	private TreeSet<String> dictionary;
	private SET<String> wordsSet;
	private int noOfRows = 0;
	private int noOfCols = 0;
	private char [][] map = null;
	
	// Initializes the data structure using the given array of strings as the dictionary.
    // (You can assume each word in the dictionary contains only the uppercase letters A through Z.)
    public BoggleSolver(String[] dictionary)
    {
    	this.trieSet = new Trie26();
    	this.dictionary = new TreeSet<String>();
    	
    	int len = dictionary.length;
    	
    	/*
    	System.out.print("Dir length is :\n======" + len + "======\n");
    	System.out.print("Tri length is :\n======" + trieSet.size() + "======\n");
    	*/
    	
    	for (int i = 0; i < len; i++)
    	{
    		this.trieSet.add(dictionary[i]);
    		this.dictionary.add(dictionary[i]);
    	}
    }
    
    // Returns the set of all valid words in the given Boggle board, as an Iterable.
    public Iterable<String> getAllValidWords(BoggleBoard board)
    {
    	wordsSet = new SET<String>();
    	noOfRows = board.rows();
    	noOfCols = board.cols();
    	map = new char[noOfRows][noOfCols];
    	
    	for (int i = 0; i < noOfRows; i++)
    	{
    		for (int j = 0; j < noOfCols; j++)
    			map[i][j] = board.getLetter(i, j);
    	}
    	
    	
    	for (int i = 0; i < noOfRows; i++)
    	{
    		for (int j = 0; j < noOfCols; j++)
    		{
    	    	boolean [][] marked = new boolean[noOfRows][noOfCols];
    			dfs(marked, i, j, "");
    		}
    	}
    	
    	//System.out.print(wordsSet.size());
    	
    	return wordsSet;
    }
    
    private void dfs(boolean [][]marked, int x, int y, String str)
    {
    	if (x < 0 || x >= noOfRows || y < 0 || y >= noOfCols)
    		return ;
    	if (marked[x][y])
    		return ;
    	
    	String strCopy = "";
    	
    	if (map[x][y] != 'Q')
    		strCopy = str + String.valueOf(map[x][y]);
    	else
    		strCopy = str + String.valueOf(map[x][y]) + "U";
    	
    	
    	if (strCopy.length() > 2)
    	{
    		/*
    		if (dictionary.contains(strCopy) && !wordsSet.contains(strCopy))
    			wordsSet.add(strCopy);
    		*/
    		
    		if (dictionary.contains(strCopy))
    		{
    			if (!wordsSet.contains(strCopy))
    				wordsSet.add(strCopy);
    		}
    		else
    		{
    			/*
    			Queue<String> queue = (Queue<String>) trieSet.keysWithPrefix(strCopy);
    			if (queue.size() == 0)
    				return ;
    			*/
    			if (!trieSet.hasPrefix(strCopy))
    				return ;
    		}
    	}

    	marked[x][y] = true;
    	
    	dfs(marked, x - 1, y, strCopy);
    	dfs(marked, x + 1, y, strCopy);
    	
    	dfs(marked, x, y - 1, strCopy);
    	dfs(marked, x, y + 1, strCopy);
    	
    	dfs(marked, x - 1, y - 1, strCopy);
    	dfs(marked, x - 1, y + 1, strCopy);
    	dfs(marked, x + 1, y - 1, strCopy);
    	dfs(marked, x + 1, y + 1, strCopy);
    	
    	marked[x][y] = false;
    }
    
    
    // Returns the score of the given word if it is in the dictionary, zero otherwise.
    // (You can assume the word contains only the uppercase letters A through Z.)
    public int scoreOf(String word)
	{
    	if (!trieSet.contains(word))
    		return 0;
    	
    	int len = word.length();
    	
    	if (len >= 0 && len <= 2)
    		return 0;
    	else if (len >= 3 && len <= 4)
    		return 1;
    	else if (len == 5)
    		return 2;
    	else if (len == 6)
    		return 3;
    	else if (len == 7)
    		return 5;
    	else
    		return 11;
	}
    
    public static void main(String[] args)
	{
    	long start = System.currentTimeMillis();

    	String pathDic = "D:\\myProgram\\java\\workspace\\Boggle\\dat\\boggle\\dictionary-algs4.txt";
    	String pathBod = "D:\\myProgram\\java\\workspace\\Boggle\\dat\\boggle\\board-q.txt";
    	
    	In in = new In(pathDic);
        String[] dictionary = in.readAllStrings();
        BoggleSolver solver = new BoggleSolver(dictionary);
        BoggleBoard board = new BoggleBoard(pathBod);
        int score = 0;
        for (String word : solver.getAllValidWords(board))
        {
            StdOut.println(word);
            score += solver.scoreOf(word);
        }
        StdOut.println("Score = " + score);
        

    	long end = System.currentTimeMillis();
    	
    	System.out.print(String.format("\nTime consuming : %f",(end - start) * 1.0 / 1000));
	}
}