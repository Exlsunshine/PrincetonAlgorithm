import java.util.ArrayList;

public class WordNet
{
	private Digraph diagraph = null;
	private RedBlackBST<String , ArrayList<Integer>> redBST = null;
	private int size = 0;

	// constructor takes the name of the two input files
	public WordNet(String synsets, String hypernyms)
	{
		if (synsets == null || hypernyms == null)
			throw new java.lang.NullPointerException("Null synsets or hypernyms params!");
		
		redBST = new RedBlackBST<String, ArrayList<Integer>>();
		readSynsetsData(synsets);
		diagraph = new Digraph(size);
		readHypernymsData(hypernyms);
	}
	
	private void readHypernymsData(String filename)
	{
		In in = new In(filename);
		
		int id = 0;
		String line = null;
		String [] data = null;
		
		while (!in.isEmpty())
		{
			line = in.readLine();
			data = line.split(",");
			id = Integer.parseInt(data[0]);
			for (int i = 1; i < data.length; i++)
				diagraph.addEdge(id, Integer.parseInt(data[i]));
		}
	}
	
	/**
	 * Load synsets file into memory.
	 * */
	private void readSynsetsData(String filename)
	{
		In in = new In(filename);
		
		int id = 0;
		String line = null;
		String [] data = null;
		String [] words = null;
		
		while (!in.isEmpty())
		{
			line = in.readLine();
			data = line.split(",");
			
			id = Integer.parseInt(data[0]);
			words = data[1].split(" ");
			for (int i = 0; i < words.length; i++)
			{
				ArrayList<Integer> list = redBST.get(words[i]);
				if (list == null)
					list = new ArrayList<Integer>();
				list.add(id);
				redBST.put(words[i], list);
			}
		}
		
		size = id + 1;
	}
	
	/**
	 *  returns all WordNet nouns
	 * */
	public Iterable<String> nouns()
	{
		return redBST.keys();
	}
	
	/**
	 *  is the word a WordNet noun?
	 * */
	public boolean isNoun(String word)
	{
		if (word == null)
			throw new java.lang.NullPointerException("Null params.");
		
		return redBST.contains(word);	
	}
	
	/**
	 *  distance between nounA and nounB (defined below)
	 */
	public int distance(String nounA, String nounB)
	{
		if (nounA == null || nounB == null)
			throw new java.lang.NullPointerException("Null params.");
		
		if (!redBST.contains(nounA) || !redBST.contains(nounB))
			throw new java.lang.IllegalArgumentException("Illegal params");
		
		SAP sap = new SAP(diagraph);
		ArrayList<Integer> idA = redBST.get(nounA);
		ArrayList<Integer> idB = redBST.get(nounB);
		
		return sap.length(idA, idB);
	}
	
	// a synset (second field of synsets.txt) that is the common ancestor of nounA and nounB
	// in a shortest ancestral path (defined below)
	public String sap(String nounA, String nounB)
	{
		if (nounA == null || nounB == null)
			throw new java.lang.NullPointerException("Null params");
		
		if (!redBST.contains(nounA) || !redBST.contains(nounB))
			throw new java.lang.IllegalArgumentException("Illegal params");
		
		//add exception here
		SAP sap = new SAP(diagraph);
		ArrayList<Integer> idA = redBST.get(nounA);
		ArrayList<Integer> idB = redBST.get(nounB);
		int ancestor = sap.length(idA, idB);
		
		for (String key : redBST.keys())
		{
			if (redBST.get(key).contains(ancestor))
				return key;
		}
		
		return null;
	}
	
	public static void main(String[] args)
	{
		String synset = "D:\\myProgram\\java\\workspace\\WordNet\\dat\\wordnet\\synsets.txt";
		String hypernyms = "D:\\myProgram\\java\\workspace\\WordNet\\dat\\wordnet\\hypernyms.txt";
		
		WordNet wdn = new WordNet(synset, hypernyms);
		System.out.printf("%d",	wdn.distance("A-line", "knock_on"));
	}
}